extends Node3D

# Gorodki — Legend of the Throw | first playable prototype
# Prototype scope: 3 traditional figures, touch/mouse aiming, rigid-body collisions,
# simplified classic progression and local solo play. Online play is intentionally future work.

const FIGURES := [
	{"name": "Пушка", "layout": [Vector2(-0.32, 0.0), Vector2(0.0, 0.0), Vector2(0.32, 0.0), Vector2(0.0, 0.32), Vector2(0.0, -0.32)]},
	{"name": "Звезда", "layout": [Vector2(0.0, 0.0), Vector2(-0.34, 0.0), Vector2(0.34, 0.0), Vector2(0.0, 0.34), Vector2(0.0, -0.34)]},
	{"name": "Колодец", "layout": [Vector2(-0.28, -0.28), Vector2(0.28, -0.28), Vector2(-0.28, 0.28), Vector2(0.28, 0.28), Vector2(0.0, 0.0)]}
]
const PIN_HEIGHT := 0.48
const PIN_RADIUS := 0.105
const THROW_LINE_Z := 4.8
const CITY_Z := -2.0
const MAX_THROWS_PER_FIGURE := 5

var current_figure := 0
var throws_used := 0
var total_score := 0
var round_active := true
var aiming := false
var aim_start := Vector2.ZERO
var aim_current := Vector2.ZERO
var shot_in_flight := false
var shot_timer := 0.0
var pins: Array[RigidBody3D] = []
var bat: RigidBody3D
var hud: CanvasLayer
var status_label: Label
var score_label: Label
var figure_label: Label
var hint_label: Label
var power_label: Label
var next_button: Button
var restart_button: Button
var aim_line: MeshInstance3D

func _ready() -> void:
	_build_world()
	_build_hud()
	_spawn_figure()
	_update_hud()

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color(0.055, 0.09, 0.075)
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.72, 0.78, 0.72)
	environment.ambient_light_energy = 0.8
	env.environment = environment
	add_child(env)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)

	var camera := Camera3D.new()
	camera.position = Vector3(0, 5.2, 9.6)
	camera.rotation_degrees = Vector3(-26.6, 0, 0)
	camera.current = true
	camera.fov = 46
	add_child(camera)

	# Playing lane
	_add_static_box("Ground", Vector3(0, -0.18, 0), Vector3(5.0, 0.35, 13.5), Color(0.34, 0.24, 0.15))
	_add_static_box("City", Vector3(0, 0.005, CITY_Z), Vector3(2.2, 0.035, 2.2), Color(0.55, 0.39, 0.22))
	_add_static_box("Left rail", Vector3(-2.48, 0.15, 0), Vector3(0.12, 0.3, 13.5), Color(0.22, 0.16, 0.12))
	_add_static_box("Right rail", Vector3(2.48, 0.15, 0), Vector3(0.12, 0.3, 13.5), Color(0.22, 0.16, 0.12))
	_add_static_box("Back rail", Vector3(0, 0.15, -6.72), Vector3(5.0, 0.3, 0.12), Color(0.22, 0.16, 0.12))
	_add_static_box("Throw line", Vector3(0, 0.012, THROW_LINE_Z), Vector3(4.8, 0.025, 0.045), Color(0.92, 0.78, 0.39))

	# Decorative trees and lantern-like posts
	for x in [-3.4, 3.4]:
		for z in [-4.5, -1.0, 2.5, 5.0]:
			_add_tree(Vector3(x, 0, z))

	aim_line = MeshInstance3D.new()
	var line_mesh := ImmediateMesh.new()
	aim_line.mesh = line_mesh
	add_child(aim_line)

func _add_static_box(node_name: String, pos: Vector3, size: Vector3, color: Color) -> void:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = size
	shape.shape = box
	body.add_child(shape)
	var mesh_instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_instance.mesh = mesh
	mesh_instance.material_override = _mat(color, 0.82)
	body.add_child(mesh_instance)
	add_child(body)

func _add_tree(pos: Vector3) -> void:
	var trunk := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.13
	cylinder.bottom_radius = 0.19
	cylinder.height = 1.15
	trunk.mesh = cylinder
	trunk.position = pos + Vector3(0, 0.57, 0)
	trunk.material_override = _mat(Color(0.25, 0.15, 0.09))
	add_child(trunk)
	var crown := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.68
	sphere.height = 1.3
	crown.mesh = sphere
	crown.position = pos + Vector3(0, 1.55, 0)
	crown.material_override = _mat(Color(0.12, 0.29, 0.18), 0.9)
	add_child(crown)

func _mat(color: Color, roughness: float = 0.72) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	return m

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 16)
	panel.custom_minimum_size = Vector2(360, 150)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.055, 0.045, 0.88)
	style.corner_radius_top_left = 16
	style.corner_radius_top_right = 16
	style.corner_radius_bottom_left = 16
	style.corner_radius_bottom_right = 16
	style.content_margin_left = 16
	style.content_margin_right = 16
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	panel.add_theme_stylebox_override("panel", style)
	hud.add_child(panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 5)
	panel.add_child(column)
	var title := Label.new()
	title.text = "ГОРОДКИ  •  ЛЕГЕНДА БРОСКА"
	title.add_theme_font_size_override("font_size", 19)
	title.add_theme_color_override("font_color", Color(0.96, 0.81, 0.49))
	column.add_child(title)

	figure_label = Label.new()
	figure_label.add_theme_font_size_override("font_size", 17)
	column.add_child(figure_label)
	score_label = Label.new()
	score_label.add_theme_font_size_override("font_size", 15)
	column.add_child(score_label)
	status_label = Label.new()
	status_label.add_theme_font_size_override("font_size", 15)
	status_label.add_theme_color_override("font_color", Color(0.78, 0.88, 0.77))
	column.add_child(status_label)

	hint_label = Label.new()
	hint_label.text = "Проведи пальцем вверх от точки броска и отпусти."
	hint_label.position = Vector2(18, 180)
	hint_label.add_theme_font_size_override("font_size", 17)
	hint_label.add_theme_color_override("font_color", Color(1, 1, 1))
	hud.add_child(hint_label)

	power_label = Label.new()
	power_label.position = Vector2(18, 212)
	power_label.add_theme_font_size_override("font_size", 15)
	power_label.add_theme_color_override("font_color", Color(0.96, 0.81, 0.49))
	hud.add_child(power_label)

	next_button = Button.new()
	next_button.text = "Следующая фигура"
	next_button.position = Vector2(18, 260)
	next_button.custom_minimum_size = Vector2(220, 52)
	next_button.visible = false
	next_button.pressed.connect(_next_figure)
	hud.add_child(next_button)

	restart_button = Button.new()
	restart_button.text = "Начать заново"
	restart_button.position = Vector2(250, 260)
	restart_button.custom_minimum_size = Vector2(180, 52)
	restart_button.pressed.connect(_restart_game)
	hud.add_child(restart_button)

func _spawn_figure() -> void:
	_clear_pins()
	var layout: Array = FIGURES[current_figure]["layout"]
	for p in layout:
		var pin := RigidBody3D.new()
		pin.name = "Gorodok"
		pin.position = Vector3(p.x, PIN_HEIGHT * 0.5 + 0.04, CITY_Z + p.y)
		pin.mass = 0.32
		pin.linear_damp = 0.55
		pin.angular_damp = 0.7
		pin.continuous_cd = true
		var collision := CollisionShape3D.new()
		var capsule := CapsuleShape3D.new()
		capsule.radius = PIN_RADIUS
		capsule.height = PIN_HEIGHT
		collision.shape = capsule
		pin.add_child(collision)
		var visual := MeshInstance3D.new()
		var mesh := CylinderMesh.new()
		mesh.top_radius = PIN_RADIUS * 0.86
		mesh.bottom_radius = PIN_RADIUS
		mesh.height = PIN_HEIGHT
		visual.mesh = mesh
		visual.material_override = _mat(Color(0.72, 0.43, 0.20), 0.48)
		pin.add_child(visual)
		add_child(pin)
		pins.append(pin)
	_spawn_bat()

func _spawn_bat() -> void:
	if is_instance_valid(bat):
		bat.queue_free()
	bat = RigidBody3D.new()
	bat.name = "ThrowingBat"
	bat.position = Vector3(0, 0.16, THROW_LINE_Z)
	bat.mass = 1.15
	bat.linear_damp = 0.1
	bat.angular_damp = 0.7
	bat.continuous_cd = true
	var collision := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.105
	shape.height = 0.78
	collision.shape = shape
	collision.rotation_degrees.x = 90  # FIX: коллайдер повёрнут так же, как картинка биты
	bat.add_child(collision)
	var bat_mat := PhysicsMaterial.new()  # FIX: скользкая бита
	bat_mat.friction = 0.15
	bat_mat.bounce = 0.1
	bat.physics_material_override = bat_mat
	var visual := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.105
	mesh.bottom_radius = 0.105
	mesh.height = 0.78
	visual.mesh = mesh
	visual.rotation_degrees.x = 90
	visual.material_override = _mat(Color(0.42, 0.22, 0.10), 0.4)
	bat.add_child(visual)
	add_child(bat)

func _clear_pins() -> void:
	for p in pins:
		if is_instance_valid(p):
			p.queue_free()
	pins.clear()

func _unhandled_input(event: InputEvent) -> void:
	if shot_in_flight or not round_active:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_begin_aim(event.position)
		else:
			_release_aim(event.position)
	elif event is InputEventScreenDrag:
		if aiming:
			aim_current = event.position
			_update_aim_visual()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_begin_aim(event.position)
		else:
			_release_aim(event.position)
	elif event is InputEventMouseMotion and aiming:
		aim_current = event.position
		_update_aim_visual()

func _begin_aim(pos: Vector2) -> void:
	aiming = true
	aim_start = pos
	aim_current = pos
	_update_aim_visual()

func _release_aim(pos: Vector2) -> void:
	if not aiming:
		return
	aiming = false
	aim_current = pos
	var drag := aim_start - aim_current
	# Drag upward on screen to throw toward the city; horizontal drag steers.
	var forward := clampf(drag.y / 190.0, 0.15, 1.0)
	var side := clampf(drag.x / 260.0, -0.65, 0.65)
	var impulse := Vector3(side * 3.0, 4.5 + forward * 0.7, -(8.0 + forward * 4.0))  # FIX: дуга, а не подскок
	if drag.length() < 12.0:
		impulse = Vector3(0, 4.7, -9.5)
	throws_used += 1
	shot_in_flight = true
	shot_timer = 0.0
	bat.freeze = false
	bat.apply_central_impulse(impulse)
	bat.apply_torque_impulse(Vector3(2.2, 0.0, 0.0))
	hint_label.text = "Бросок! Смотри, как разлетаются городки."
	power_label.text = ""
	aim_line.mesh.clear_surfaces()

func _update_aim_visual() -> void:
	var drag := aim_start - aim_current
	var strength := clampf(drag.length() / 260.0, 0.0, 1.0)
	power_label.text = "Сила броска: %d%%" % int(strength * 100.0)
	var mesh := aim_line.mesh as ImmediateMesh
	mesh.clear_surfaces()
	mesh.surface_begin(Mesh.PRIMITIVE_LINES)
	mesh.surface_add_vertex(Vector3(0, 0.08, THROW_LINE_Z))
	mesh.surface_add_vertex(Vector3(clampf(drag.x / 130.0, -1.2, 1.2), 0.08, THROW_LINE_Z - clampf(drag.y / 80.0, 0.8, 4.0)))
	mesh.surface_end()

func _process(delta: float) -> void:
	if shot_in_flight:
		shot_timer += delta
		if shot_timer > 2.8:
			_finish_throw()

func _finish_throw() -> void:
	shot_in_flight = false
	var fallen := 0
	for pin in pins:
		if not is_instance_valid(pin):
			continue
		var tilted := absf(pin.rotation.x) > 0.48 or absf(pin.rotation.z) > 0.48
		var displaced := Vector2(pin.position.x, pin.position.z - CITY_Z).length() > 0.42
		if tilted or displaced or pin.position.y < -0.15:
			fallen += 1
			pin.queue_free()
	total_score += fallen
	# Remove fallen bodies from active list
	var remaining: Array[RigidBody3D] = []
	for pin in pins:
		if is_instance_valid(pin) and not pin.is_queued_for_deletion():
			remaining.append(pin)
	pins = remaining
	if pins.is_empty():
		status_label.text = "Фигура выбита! Отличный бросок."
		next_button.visible = true
		hint_label.text = "Все городки выбиты. Переходи к следующей фигуре."
	elif throws_used >= MAX_THROWS_PER_FIGURE:
		status_label.text = "Попытки закончились. Осталось городков: %d" % pins.size()
		next_button.visible = true
		hint_label.text = "Фигура не выбита полностью. Можно перейти дальше."
	else:
		status_label.text = "Сбито: %d  •  Осталось: %d" % [fallen, pins.size()]
		hint_label.text = "Следующий бросок: проведи пальцем вверх и отпусти."
		_spawn_bat()
	_update_hud()

func _next_figure() -> void:
	if current_figure >= FIGURES.size() - 1:
		round_active = false
		next_button.visible = false
		hint_label.text = "Тренировка завершена! Ты прошёл все три фигуры."
		status_label.text = "Итог: %d городков сбито из 15." % total_score
		return
	current_figure += 1
	throws_used = 0
	next_button.visible = false
	round_active = true
	_spawn_figure()
	_update_hud()

func _restart_game() -> void:
	current_figure = 0
	throws_used = 0
	total_score = 0
	round_active = true
	shot_in_flight = false
	next_button.visible = false
	hint_label.text = "Проведи пальцем вверх от точки броска и отпусти."
	_spawn_figure()
	_update_hud()

func _update_hud() -> void:
	figure_label.text = "Фигура: %s  •  %d/%d" % [FIGURES[current_figure]["name"], current_figure + 1, FIGURES.size()]
	score_label.text = "Сбито всего: %d  •  Бросок: %d/%d" % [total_score, throws_used, MAX_THROWS_PER_FIGURE]
	if not shot_in_flight and pins.size() > 0:
		status_label.text = "Городков осталось: %d" % pins.size()
